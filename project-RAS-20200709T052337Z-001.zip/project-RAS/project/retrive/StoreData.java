package retrive;

import java.util.ArrayList;

public class StoreData
{
  String seat_no,name;
  double sgpa,cgpa;
  byte sub_count;
  short cred;
  ArrayList<StoreDataMarks> data=new ArrayList<>();
  
  StoreData(String seat_no,String name,double sgpa,double cgpa,byte sub_count,short cred,ArrayList<StoreDataMarks> data)
  {
      this.seat_no=seat_no;
      this.name=name;
      this.sgpa=sgpa;
      this.cgpa=cgpa;
      this.sub_count=sub_count;
      this.cred=cred;
      this.data=data;
  }

   
  
  public String getSeatNumber()
  {
      return seat_no;
  }
  public String getName()
  {
      return name;
  }
  public double getSgpa()
  {
      return sgpa;
  }
  public double getCgpa()
  {
      return cgpa;
  }
  public byte getSubjectCount()
  {
      return sub_count;
  }
  public short getCredits()
  {
      return cred;
  }
  public ArrayList<StoreDataMarks> getMarksArray()
  {
      return data;
  }
  public int total_marks(ArrayList<StoreDataMarks> sm,byte sub_count)
  {
      int tot=0;
          for(int i=0;i<sub_count;i++)
          {
            int temp=(sm.get(i).getInsemEndsemMarks()+sm.get(i).getPrMarks()+sm.get(i).getTwMarks()+sm.get(i).getOrMarks());
            tot=tot+temp;
          }
     return tot;
  }

 
    public int total(ArrayList<StoreDataMarks> sm,byte sub_count)
  {
      int tot=0;
          for(int i=0;i<sub_count;i++)
          {
            int temp=(sm.get(i).getInsemEndsemTotal()+sm.get(i).getPrTotal()+sm.get(i).getTwTotal()+sm.get(i).getOrTotal());
            tot=tot+temp;
          }
     return tot;
  }
    
   public int countFail(ArrayList<StoreDataMarks> sm,byte sub_count)
   {
       int count=0;
        for(int i=0;i<sub_count;i++)
          {
            if(sm.get(i).getGrade().contains("F") && sm.get(i).getEndsemTotal()!=0)
                count++;
          }
     return count;
   }
   public String subjectGrade(ArrayList<StoreDataMarks> sm,String sub_name,int track,byte sub_count)
   {
       String grade=null;
        for(int i=0+track;i<sub_count+track;i++)
          {
            if(sm.get(i).getSubject().contains(sub_name) && sm.get(i).getEndsemTotal()!=0)
            {
               grade=sm.get(i).getGrade();
            }
               
          }
     return grade;
   }
}







     
   