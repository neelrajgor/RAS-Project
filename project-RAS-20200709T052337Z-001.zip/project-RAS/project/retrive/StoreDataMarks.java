package retrive;

public class StoreDataMarks
{
    String sub;
    byte insem_marks,insem_total,endsem_marks,endsem_total,insem_endsem_marks,insem_endsem_total,tw,tw_tot,pr,pr_tot,or,or_tot;
    String grade;
    StoreDataMarks(String sub,byte insem_marks,byte insem_total,byte endsem_marks,byte endsem_total,byte insem_endsem_marks,byte insem_endsem_total,byte tw,byte tw_tot,byte pr,byte pr_tot,byte or,byte or_tot,String grade)
    {
        this.sub=sub;
        this.insem_marks=insem_marks;
        this.insem_total=insem_total;
        this.endsem_marks=endsem_marks;
        this.endsem_total=endsem_total;
        this.insem_endsem_marks=insem_endsem_marks;
        this.insem_endsem_total=insem_endsem_total;
        this.tw=tw;
        this.tw_tot=tw_tot;
        this.pr=pr;
        this.pr_tot=pr_tot;
        this.or=or;
        this.or_tot=or_tot;
        this.grade=grade;
    }
    public String getSubject()
    {
        return sub;
    }
   public byte getInsemMarks()
    {
        return insem_marks;
    }
   public byte getInsemTotal()
    {
        return insem_total;
    }
   public byte getEndsemMarks()
    {
        return endsem_marks;
    }
   public byte getEndsemTotal()
    {
        return endsem_total;   
    }
   public byte getInsemEndsemMarks()
    {
        return insem_endsem_marks;
    }
   public byte getInsemEndsemTotal()
    {
        return insem_endsem_total;
    }
   public byte getTwMarks()
    {
        return tw;
    }
   public byte getTwTotal()
    {
        return tw_tot;
    }
   public byte getPrMarks()
    {
        return pr;
    }
   public byte getPrTotal()
    {
        return pr_tot;
    }
  public  byte getOrMarks()
    {
        return or;
    }
   byte getOrTotal()
   {
       return or_tot;
   }
   public String getGrade()
   {
       return grade;
   }
   void setGrade(String grade)
   {
       this.grade=grade;
   }
}