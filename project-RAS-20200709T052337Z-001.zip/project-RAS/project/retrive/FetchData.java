package retrive;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class FetchData
{
    Pattern p;
    Matcher m;
     int store_marks[]=new int[2];
    String seat_no="",prn_no;
    String test_marks;
    String name;
    double sgpa,cgpa;
    short credits;
    String fetchCollegeName(String str[])
    {
          String str2[]=str[0].split("\n");
          String college_name=str2[3].substring(str2[3].indexOf(":")+1,str2[3].length()).trim();
       return college_name;
    }
     String fetchCourse(String str[])
    {
        String Course=null;
        String str2[]=str[0].split("\n");
        p=Pattern.compile("[(]{1}[A-Z]*[)]{1}");
        m=p.matcher(str2[4]);
        try
        {
            while(m.find())
            {
             Course=m.group();
            }
            //int length = Course.length();
        }
        catch(NullPointerException e)
        {
            Course="First Year";
        }
      return Course;
    }
    String fetchYear(String str[])
    {
        String year=null;
        String str2[]=str[0].split("\n");
        String str3[]=str2[1].split(",");
                if(str3[1].contains("F.E."))
                  {
                      year="FE";
                  }
                  else if(str3[1].contains("S.E."))
                  {
                      year="SE";
                  }
                  else if(str3[1].contains("T.E."))
                  {
                      year="TE";
                  }
                  else if(str3[1].contains("B.E."))
                  {
                      year="BE";
                  }
        return year;
    }
    
    boolean fetchSem(String str[])
    {
        boolean sem=false;
        String str2[]=str[0].split("\n");
        String str3[]=str2[1].split(",");
                if(str3[2].contains("DEC") || str3[2].contains("OCT") || str3[2].contains("NOV"))
                    sem=false;
                  else if(str3[2].contains("MAY") || str3[2].contains("APR"))
                      sem=true;
        return sem;
    }
    
    String fetchSeatNo(String raw_info)
    {
        p=Pattern.compile("\\s[FSTB]{1}[0-9]{9}\\s");
        m=p.matcher(raw_info);
        while(m.find())
           seat_no=m.group();
        return seat_no;
    }
    
    String fetchPrnNo(String raw_info)
    {
        p=Pattern.compile("\\s[0-9]{8}[A-Z]{1}\\s");
        m=p.matcher(raw_info);
        while(m.find())
           prn_no=m.group();  
      return prn_no;
    }
    
    String fetchName(String raw_info)
    {
        p=Pattern.compile("\\s[A-Z]+\\s[A-Z]+\\s[A-Z]*\\s\\s");
        m=p.matcher(raw_info);
        while(m.find())
        {
           name=m.group();
           break;
        }
        return name;
    }
    
    double fetchSgpa(String raw_info)
    {
        p=Pattern.compile("[S]{1}[G]{1}[P]{1}[A]{1}[0-4]?\\s[:]\\s[0-9]+[0-9]*[.]?[0-9]*[0-9]*[,]{1}");
        m=p.matcher(raw_info);
            if(m.find())
            {
                String marks=m.group();
            int indexOf = marks.indexOf(":")+1;
            int indexOf1 = marks.indexOf(",");
             String trim_string=marks.substring(indexOf, indexOf1).trim();
                sgpa=Double.parseDouble(trim_string);
            }
            else
                sgpa=0.00;
        return sgpa;
    }
    
    double fetchCgpa(String raw_info)
    {
       p=Pattern.compile("[C]{1}[G]{1}[P]{1}[A]{1}\\s[:]\\s[0-9]+[0-9]*[.]?[0-9]*[0-9]*\\s");
       m=p.matcher(raw_info);
       if(m.find())
       {
           String marks=m.group();
           marks= marks.substring(marks.indexOf(":")+1);
           cgpa=Double.parseDouble(marks);
       }
       else
           cgpa=0.00;
       return cgpa;
    }
    
    short fetchCredits(String raw_info,double sgpa,boolean sem)
    {
        p=Pattern.compile("[C]{1}[R]{1}[E]{1}[D]{1}[I]{1}[T]{1}[S]{1}\\s[E]{1}[A]{1}[R]{1}[N]{1}[E]{1}[D]{1}\\s[:]\\s\\d\\d*");
        m=p.matcher(raw_info);
        if(sgpa==0.0)
        {
            while(m.find())
            {
                p=Pattern.compile("\\d\\d*");
                m=p.matcher(m.group());
                if(m.find())
                    credits=Short.parseShort(m.group());
            }
        }
        else
        {
            if(sem==false)
                credits=25;
            else
                credits=50;
                
        }
        return credits;
    }
    
    String fetchSem(String raw_info)
    {
        MarksLocator m1=new MarksLocator();
        String temp=raw_info.trim();
        String marks = null;
        if(temp.contains("SEM.:2"))
                 marks=m1.locateSem12(temp);
        if(!temp.contains("SEM.:2"))
                 marks=m1.locateSem1(temp);
     return marks;
    }
    
    String fetchSubject(String raw_marks)
    {
        p=Pattern.compile("\\s\\d{6}[A-Z]?\\s");
        m=p.matcher(raw_marks);
        while(m.find())
        {
           test_marks=m.group();
           break;
        }
        return test_marks;
    }
    
    String fetchCurrentSubject(String raw_marks)
    {
        p=Pattern.compile("\\s\\d{6}[A-Z]?\\s[*]{1}");
        m=p.matcher(raw_marks);
        while(m.find())
        {
           test_marks=m.group();
           break;
        }
        return test_marks;
    }
    
    byte fetchSubjectCount(String raw_info)
    {
        MarksLocator m1=new MarksLocator();
        byte count_subject=0;
        String temp=raw_info.trim();
        String marks = null;
        if(temp.contains("SEM.:2"))
                 marks=m1.locateSem12(temp);
        if(!temp.contains("SEM.:2"))
                 marks=m1.locateSem1(temp);
        
        p=Pattern.compile("\\s\\d{6}[A-Z]?\\s");
        m=p.matcher(marks);
        while(m.find())
        {
           count_subject++;
        }
      return count_subject;
    }
    String fetchOnline(String raw_marks)
    {
        p=Pattern.compile("\\s\\s?\\s[\\d-#$![A-Z]]*[/-]{1}[\\d-[A-Z]]*\\s\\s");
        m=p.matcher(raw_marks);
        while(m.find())
        {
            test_marks=m.group();
            break;
        }
      return test_marks;
    }
    
    String fetchTheory(String raw_marks,int index)
    {
        p=Pattern.compile("\\s\\s?\\s[\\d-#$![A-Z]]*[/-]{1}[\\d-[A-Z]]*\\s\\s");
        m=p.matcher(raw_marks);
        while(m.find(index))
        {
            test_marks=m.group();
            break;
        }
      return test_marks;
    }
    
    String fetchPratical(String raw_marks,int index)
    {
        p=Pattern.compile("\\s\\s?\\s[\\d-#$![A-Z]]*[/-]{1}[\\d-[A-Z]]*\\s\\s");
        m=p.matcher(raw_marks);
        while(m.find(index))
        {
            test_marks=m.group();
            break;
        }
      return test_marks;
    }
    
    String fetchTermWork(String raw_marks,int index)
    {
        p=Pattern.compile("\\s\\s?\\s[\\d-#$![A-Z]]*[/-]{1}[\\d-[A-Z]]*\\s\\s");
        m=p.matcher(raw_marks);
        while(m.find(index))
        {
            test_marks=m.group();
            break;
        }
      return test_marks;
    }
    
    String fetchOnlineTheory(String raw_marks,int index)
    {
        p=Pattern.compile("\\s\\s?\\s[\\d-#$![A-Z]]*[/-]{1}[\\d-[A-Z]]*\\s\\s");
        m=p.matcher(raw_marks);
        while(m.find(index))
        {
            test_marks=m.group();
            break;
        }
      return test_marks;
    }
    
    String fetchOral(String raw_marks,int index)
    {
        p=Pattern.compile("\\s\\s?\\s[\\d-#$![A-Z]]*[/-]{1}[\\d-[A-Z]]*\\s\\s");
        m=p.matcher(raw_marks);
        while(m.find(index))
        {
            test_marks=m.group();
            break;
        }
      return test_marks;
    }
    
    String fetchGrade(String raw_marks)
    {
        p=Pattern.compile("\\s\\s\\s[O]?[B+]?[A]?[A+]?[B]?[C]?[P]?[F]?\\s\\s\\s?");
        m=p.matcher(raw_marks);
        while(m.find())
        {
            test_marks=m.group();
            break;
        }
        test_marks.trim();
      return test_marks;
    }
    
    int[] fetchMarks(String raw_marks)
    {
        int a=0,b=0;
        if(raw_marks.contains("AB"))
                  {
                    String temp[]= raw_marks.split("/");
                    temp[0]=temp[0].trim();
                    temp[1]=temp[1].trim();
                    b=Integer.parseInt(temp[1]);
                  }
                  else if(raw_marks.contains("-------"))
                  {
                     a=0;
                     b=0;
                  }
                  else
                  {
                    String temp[]=raw_marks.split("/");
                    if(temp[0].contains("$"))
                        temp[0]=temp[0].replace('$',' ');
                    else if(temp[0].contains("#"))
                        temp[0]=temp[0].replace('#',' ');
                    else if(temp[0].contains("!"))
                        temp[0]=temp[0].replace('!',' ');
                    temp[0]=temp[0].trim();
                    temp[1]=temp[1].trim();
                    a=Integer.parseInt(temp[0]);
                    b=Integer.parseInt(temp[1]);
                  }
              store_marks[0]=a;
              store_marks[1]=b;
      return store_marks;
    }
}
