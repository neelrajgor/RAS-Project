package retrive;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import java.util.regex.Pattern;

public class readpdf
{
    File f1;
    PDDocument pd;
    PDFTextStripper in;
    StringBuilder sb;
    StoreData s;
    StoreDataMarks sm;
    FetchData f2;
    Pattern p;
    ArrayList<StoreDataMarks> arr1;
    ArrayList<StoreData> arr;
    public static String college_name,course,year;
    public static boolean sem;
    public ArrayList<StoreData> pdf(String address)
    {
                                //C:/FinalSE_Result.pdf
        try {
            f1=new File(address);
            pd=PDDocument.load(f1);
            in=new PDFTextStripper();       
            sb=new StringBuilder();
            sb.append(in.getText(pd).replace("..........CONFIDENTIAL- FOR VERIFICATION AND RECORD ONLY AT COLLEGE, NOT FOR DISTRIBUTION...........","...................................................................................................."));
            p=Pattern.compile("[.]{4,}");
            String str[]=p.split(sb);
            arr=new ArrayList<>();
            f2=new FetchData();
            
            college_name=f2.fetchCollegeName(str);
            course=f2.fetchCourse(str);
            year=f2.fetchYear(str);
            sem=f2.fetchSem(str);
           for(int i=0;i<str.length-1;i++)
            {
                if(str[i].contains("SAVITRIBAI"))
                    continue;
                
                String h1=f2.fetchSeatNo(str[i]).trim();
                if(h1.isEmpty())
                    h1=f2.fetchPrnNo(str[i]);
                String h2=f2.fetchName(str[i]);
                double d1=f2.fetchSgpa(str[i]);
                double d2 = f2.fetchCgpa(str[i]);
                short cred = f2.fetchCredits(str[i],d1,sem);
                String substr=f2.fetchSem(str[i]);
                 byte b1=f2.fetchSubjectCount(str[i]);
               Pattern p2=Pattern.compile("\n");
                String[] str1=p2.split(substr);
                int len1 = str1.length;
                 byte a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12;
                 String sub,gra;
                 int split_marks[];
                 arr1=new ArrayList<>();
                 for(int j=0;j<str1.length;j++)
                 {
                     //subject
                     
                  sub=f2.fetchSubject(str1[j]);
                 
                 String g2=f2.fetchOnline(str1[j]);
                 split_marks=f2.fetchMarks(g2);
                 a1=(byte)split_marks[0];
                 a2=(byte)split_marks[1];
                
                    //endsem/theory
                    
                 int index1=str1[j].indexOf(g2);
                 index1=index1+7;
                 String g3=f2.fetchTheory(str1[j], index1);
                 split_marks=f2.fetchMarks(g3);
                 a3=(byte)split_marks[0];
                 a4=(byte)split_marks[1];
               
                    //insem+endsem
                    
                 index1=index1+7;
                 String g4=f2.fetchOnlineTheory(str1[j], index1);
                 split_marks=f2.fetchMarks(g4);
                 a5=(byte)split_marks[0];
                 a6=(byte)split_marks[1];
               
                    //Termwork
                    
                 index1=index1+7;
                 String g5=f2.fetchTermWork(str1[j], index1);
                 split_marks=f2.fetchMarks(g5);
                 a7=(byte)split_marks[0];
                 a8=(byte)split_marks[1];
                
                    //Pratical
                 
                 index1=index1+10;
                 String g6=f2.fetchPratical(str1[j], index1);
                 split_marks=f2.fetchMarks(g6);
                 a9=(byte)split_marks[0];
                 a10=(byte)split_marks[1];
                 
                    //Oral
                 
                 index1=index1+10;
                 String g7=f2.fetchOral(str1[j], index1);
                 split_marks=f2.fetchMarks(g7);
                 a11=(byte)split_marks[0];
                 a12=(byte)split_marks[1];
                 
                    //Grade
                 gra=f2.fetchGrade(str1[j]);
                 sm=new StoreDataMarks(sub,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,gra);
                 arr1.add(sm);
                 }
                 s=new StoreData(h1,h2,d1,d2,b1,cred,arr1);
                 arr.add(s);
            }
           
             /* for(StoreData temp1:arr)
              {
                  System.out.println("NAME--> "+temp1.getName());
                  for(StoreDataMarks temp2:temp1.getMarksArray())
                  {
                      System.out.println("INSEM--> "+temp2.getInsemMarks()+" (IN+END)--> "+temp2.getInsemEndsemMarks());
                  }
              }*/
            pd.close();
           }catch (IOException ex) {
            Logger.getLogger(readpdf.class.getName()).log(Level.SEVERE, null, ex);
            }
       return arr;
    }
}