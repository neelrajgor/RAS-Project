package retrive;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MarksLocator
{
    Pattern p;
    Matcher m;
    String sem1;
    String sem1_2;
    int start,end,start2,end2;
    String test;
    
    public String locateSem1(String raw_info2)
    {
                           //calculating start index
       p=Pattern.compile("\\s\\d{6}\\s");
       m=p.matcher(raw_info2);
       while(m.find())
       {
          test=m.group();
          break;
       }
        start=raw_info2.indexOf(test);
        
                            //calculating end index
        p=Pattern.compile("[A-Z]*[A-Z]*[A-Z]*[A-Z]*[A-Z]*[A-Z]*[ ]*[Y]*[E]*[A]*[R]*[ ]*[S]{1}[G]{1}[P]{1}[A]{1}[0-2]*");
        m=p.matcher(raw_info2);
            while(m.find())
            {
               test=m.group();
               break;
            }
            for(int j=0;j<10;j++)
            {
                char a=raw_info2.charAt(raw_info2.indexOf(test)-j);
                if(a=='0' || a=='1' || a=='2' || a=='3' || a=='4' || a=='5' || a=='6' || a=='7' || a=='8' || a=='9') 
                {
                    end=raw_info2.indexOf(test)-j+1;
                }
            }
            sem1=raw_info2.substring(start,end);
            
     return sem1;
    }
    
    public String locateSem12(String raw_info2)
    {
                        //calculating start index-1
       p=Pattern.compile("\\s\\d{6}\\s");
       m=p.matcher(raw_info2);
       while(m.find())
       {
          test=m.group();
          break;
       }
        start=raw_info2.indexOf(test);
        
                        //calculating end index-1
        p=Pattern.compile("[S]{1}[E]{1}[M]{1}[.]{1}[:]{1}[2]{1}\\s");
        m=p.matcher(raw_info2);
         while(m.find())
         {
               test=m.group();
               break;
         }
          for(int j=0;j<10;j++)
            {
                char a=raw_info2.charAt(raw_info2.indexOf(test)-j);
                if(a=='0' || a=='1' || a=='2' || a=='3' || a=='4' || a=='5' || a=='6' || a=='7' || a=='8' || a=='9') 
                {
                    end=raw_info2.indexOf(test)-j+2;
                }
            }
                            //calculating start index-2
            p=Pattern.compile("\\s\\d{6}\\s");
            m=p.matcher(raw_info2);
           int semindex=raw_info2.indexOf("SEM.:2");
            while(m.find(semindex))
            {
                test=m.group();
                break;
            }
              start2=raw_info2.indexOf(test);
             
              
                             //calculating end index-2
             p=Pattern.compile("[A-Z]*[A-Z]*[A-Z]*[A-Z]*[A-Z]*[A-Z]*[ ]*[Y]*[E]*[A]*[R]*[ ]*[S]{1}[G]{1}[P]{1}[A]{1}[0-2]*");
             m=p.matcher(raw_info2);
            while(m.find())
            {
               test=m.group();
               break;
            }
            for(int j=0;j<10;j++)
            {
                char a=raw_info2.charAt(raw_info2.indexOf(test)-j);
                if(a=='0' || a=='1' || a=='2' || a=='3' || a=='4' || a=='5' || a=='6' || a=='7' || a=='8' || a=='9') 
                {
                    end2=raw_info2.indexOf(test)-j+1;
                }
            }
            
                             //Calculating overall index
             String marks=raw_info2.substring(start,end);
             String marks1=raw_info2.substring(start2,end2);
             sem1_2=marks.concat("\n"+marks1);
             
        return sem1_2;
    }
}
