package excel;

import analysis.A;
import java.util.ArrayList;
import org.apache.poi.ss.usermodel.BorderExtent;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.PropertyTemplate;
import retrive.StoreData;

class sheet1
{
       A z=new A();
       Styles s=Styles.ENDSEMSTYLE;
   void execute(Workbook wb,Sheet s1,ArrayList<StoreData> pdf,boolean sem,int tot)
   {
           CellStyle sheet1mainStyle = s.sheet1mainStyle(wb);
           CellStyle sheet1insemStyle = s.sheet1insemStyle(wb);
           CellStyle sheet1endsemStyle = s.sheet1endsemStyle(wb);
           CellStyle sheet1totalStyle = s.sheet1totalStyle(wb);
           CellStyle sheet1twStyle = s.sheet1twStyle(wb);
           CellStyle sheet1prStyle = s.sheet1prStyle(wb);
           CellStyle sheet1orStyle = s.sheet1orStyle(wb);
       Row row=s1.createRow(4);
        Cell cell=row.createCell(0);
        s1.setColumnWidth(0,1500);
        row.setHeight((short)800);
        cell.setCellValue("Sr.\n No.");
        cell.setCellStyle(sheet1mainStyle);
          
        cell=row.createCell(1);
        s1.setColumnWidth(1,4000);
        cell.setCellValue("SEAT/PRN"
                + "\n NUMBER");
        cell.setCellStyle(sheet1mainStyle);
        
         cell=row.createCell(2);
        s1.setColumnWidth(2,10000);
        cell.setCellValue("NAME");
        cell.setCellStyle(sheet1mainStyle);
        
        int r1=3,r2=8;
        int write=3;
       Row row2=s1.createRow(3);
       byte stu_count=0;
       byte subjectCount = pdf.get(0).getSubjectCount();
       byte subjectCount1 = pdf.get(1).getSubjectCount();
       if(subjectCount>subjectCount1)
       {
           stu_count=subjectCount;
       }
       else if(subjectCount<subjectCount1)
       {
           stu_count=subjectCount1;
       }
       else
       {
          stu_count=subjectCount; 
       }
        for(int i=0;i<stu_count;i++)
        {
        s1.addMergedRegion(new CellRangeAddress(3,3,r1,r2));
        cell =row2.createCell(write);
        String subject = pdf.get(0).getMarksArray().get(i).getSubject();
        cell.setCellValue(subject);
        cell.setCellStyle(sheet1mainStyle);
       
        int a=r1;
        cell =row.createCell(a);
        s1.setColumnWidth(a,1500);
        cell.setCellValue("IN");
        cell.setCellStyle(sheet1mainStyle);
        a++;
        
        
         cell =row.createCell(a);
         s1.setColumnWidth(a,1500);
         cell.setCellValue("END");
         cell.setCellStyle(sheet1mainStyle);
         a++;
         
        
        cell =row.createCell(a);
        s1.setColumnWidth(a,1800);
        cell.setCellValue("TOTAL");
        cell.setCellStyle(sheet1mainStyle);
        a++;
        
        
         cell =row.createCell(a);
         s1.setColumnWidth(a,1500);
         cell.setCellValue("TW");
         cell.setCellStyle(sheet1mainStyle);
         a++;
        
        
         cell =row.createCell(a);
         s1.setColumnWidth(a,1500);
         cell.setCellValue("PR");
         cell.setCellStyle(sheet1mainStyle);
         a++;
         
        
         cell =row.createCell(a);
         s1.setColumnWidth(a,1500);
         cell.setCellValue("OR");
         cell.setCellStyle(sheet1mainStyle);
         
        write+=6;
        r1+=6;
        r2+=6;
        }
           
            cell=row.createCell(r1);
            s1.setColumnWidth(r1,3000);
            cell.setCellValue("Total Credits");
            cell.setCellStyle(sheet1mainStyle);
            r1++;
        
            cell=row.createCell(r1);
            s1.setColumnWidth(r1,3000);
            cell.setCellValue("Total Marks obtained");
            cell.setCellStyle(sheet1mainStyle);
            r1++;
  
             cell=row.createCell(r1);
            s1.setColumnWidth(r1,3000);
            cell.setCellValue("SGPA");
            cell.setCellStyle(sheet1mainStyle);
            r1++;
            
            cell=row.createCell(r1);
            s1.setColumnWidth(r1,3000);
            cell.setCellValue("CGPA");
            cell.setCellStyle(sheet1mainStyle);
            r1++;
           
            cell=row.createCell(r1);
            s1.setColumnWidth(r1,3000);
            cell.setCellValue("Percentage");
            cell.setCellStyle(sheet1mainStyle);
            r1++;
            
            cell=row.createCell(r1);
            s1.setColumnWidth(r1,3000);
            cell.setCellValue("Class");
            cell.setCellStyle(sheet1mainStyle);
            r1++;
            
        int j=1;
        int k=0;
          ArrayList<Float> studentPercent = z.studentPercent(pdf,true);
           ArrayList<Float> studentMarks = z.studentPercent(pdf,false);
          int t=0;
          int pdfSize=0;
          int rem_size=0;
          if(sem)
            pdfSize=pdf.size();
          else
          {
           rem_size=pdf.size()-tot;
           pdfSize=pdf.size()-rem_size;
          }
        for(int i=5;i<pdfSize+5;i++)
        {
          row2=s1.createRow(i);
          cell=row2.createCell(0);
          String tempstr=j+".)";
          cell.setCellValue(tempstr);
          cell.setCellStyle(sheet1mainStyle);
          j++;
          
          cell=row2.createCell(1);
          cell.setCellValue(pdf.get(k).getSeatNumber());
          cell.setCellStyle(sheet1mainStyle);
          
          cell=row2.createCell(2);
          cell.setCellValue(pdf.get(k).getName());
          cell.setCellStyle(sheet1mainStyle);
          addexcelmarks(pdf,wb,k,cell,row2,s1,sheet1insemStyle,sheet1endsemStyle,sheet1totalStyle,sheet1twStyle,sheet1prStyle,sheet1orStyle);
          
          int marks_col=(pdf.get(0).getSubjectCount()*6)+3;
          cell=row2.createCell(marks_col);
          cell.setCellValue(pdf.get(k).getCredits());
          cell.setCellStyle(sheet1mainStyle);
          
          marks_col=(pdf.get(0).getSubjectCount()*6)+4;
          cell=row2.createCell(marks_col);
          cell.setCellValue(studentMarks.get(k));
          cell.setCellStyle(sheet1mainStyle);
          
          marks_col=(pdf.get(0).getSubjectCount()*6)+5;
          cell=row2.createCell(marks_col);
          if(pdf.get(k).getSgpa()==0)
              cell.setCellValue("-");
          else
          cell.setCellValue(pdf.get(k).getSgpa());
            cell.setCellStyle(sheet1mainStyle);
          
          marks_col=(pdf.get(0).getSubjectCount()*6)+6;
          cell=row2.createCell(marks_col);
          if(pdf.get(k).getCgpa()==0)
              cell.setCellValue("-");
          else
          cell.setCellValue(pdf.get(k).getCgpa());
            cell.setCellStyle(sheet1mainStyle);
          
          marks_col=(pdf.get(0).getSubjectCount()*6)+7;
          cell=row2.createCell(marks_col);
          cell.setCellValue(studentPercent.get(k));
          cell.setCellStyle(sheet1mainStyle);
          
          marks_col=(pdf.get(0).getSubjectCount()*6)+8;
          cell=row2.createCell(marks_col);
          if(studentPercent.get(k)>=65)
          {
              cell.setCellValue("DSC");
              cell.setCellStyle(sheet1mainStyle);
          }
          else if(studentPercent.get(k)>=60 && studentPercent.get(k)<=65)
          {
              cell.setCellValue("FC");
              cell.setCellStyle(sheet1mainStyle);
          }
          else if(studentPercent.get(k)>=50 && studentPercent.get(k)<=60)
          {
              cell.setCellValue("SC");
              cell.setCellStyle(sheet1mainStyle);
          }
          else if(studentPercent.get(k)>=40 && studentPercent.get(k)<=50)
          {
              cell.setCellValue("PASS");
              cell.setCellStyle(sheet1mainStyle);
          }
          else
          {
              cell.setCellValue("FAIL");
              cell.setCellStyle(sheet1mainStyle);
          }
          k++;
        }
        
        PropertyTemplate pt=new PropertyTemplate();
        pt.drawBorders(new CellRangeAddress(3,(pdfSize+5)-1,0,r1-1), BorderStyle.MEDIUM, BorderExtent.ALL);
        pt.applyBorders(s1);
   }

    void addexcelmarks(ArrayList<StoreData>pdf,Workbook wb,int d,Cell cell,Row row2,Sheet s1,CellStyle s2,CellStyle s3,CellStyle s4,CellStyle s5,CellStyle s6,CellStyle s7) 
    {
        int track=3;
        for(int l=0;l<pdf.get(d).getSubjectCount();l++)
          {
             if(pdf.get(d).getMarksArray().get(l).getInsemTotal()!=0)
             {
               cell=row2.createCell(track);
               cell.setCellValue(pdf.get(d).getMarksArray().get(l).getInsemMarks());
               cell.setCellStyle(s2);
             }
             if(pdf.get(d).getMarksArray().get(l).getInsemTotal()==0)
             {
               cell=row2.createCell(track);
               cell.setCellValue("-");
               cell.setCellStyle(s2);
             }
             track++;
             if(pdf.get(d).getMarksArray().get(l).getEndsemTotal()!=0)
             {
               cell=row2.createCell(track);
               cell.setCellValue(pdf.get(d).getMarksArray().get(l).getEndsemMarks());
               cell.setCellStyle(s3);
             }
             if(pdf.get(d).getMarksArray().get(l).getEndsemTotal()==0)
             {
               cell=row2.createCell(track);
               cell.setCellValue("-");
               cell.setCellStyle(s3);
             }
             track++;
             if(pdf.get(d).getMarksArray().get(l).getInsemEndsemTotal()!=0)
             {
               cell=row2.createCell(track);
               cell.setCellValue(pdf.get(d).getMarksArray().get(l).getInsemEndsemMarks());
               cell.setCellStyle(s4);
             }
             if(pdf.get(d).getMarksArray().get(l).getInsemEndsemTotal()==0)
             {
               cell=row2.createCell(track);
               cell.setCellValue("-");
               cell.setCellStyle(s4);
             }
             track++;
             if(pdf.get(d).getMarksArray().get(l).getTwTotal()!=0)
             {
               cell=row2.createCell(track);
               cell.setCellValue(pdf.get(d).getMarksArray().get(l).getTwMarks());
               cell.setCellStyle(s5);
             }
             if(pdf.get(d).getMarksArray().get(l).getTwTotal()==0)
             {
               cell=row2.createCell(track);
               cell.setCellValue("-");
               cell.setCellStyle(s5);
             }
             track++;
             if(pdf.get(d).getMarksArray().get(l).getPrTotal()!=0)
             {
               cell=row2.createCell(track);
               cell.setCellValue(pdf.get(d).getMarksArray().get(l).getPrMarks());
               cell.setCellStyle(s6);
             }
             if(pdf.get(d).getMarksArray().get(l).getPrTotal()==0)
             {
               cell=row2.createCell(track);
               cell.setCellValue("-");
               cell.setCellStyle(s6);
             }
             track++;
             if(pdf.get(d).getMarksArray().get(l).getOrMarks()!=0)
             {
               cell=row2.createCell(track);
               cell.setCellValue(pdf.get(d).getMarksArray().get(l).getOrMarks());
               cell.setCellStyle(s7);
             }
             if(pdf.get(d).getMarksArray().get(l).getOrMarks()==0)
             {
               cell=row2.createCell(track);
               cell.setCellValue("-");
               cell.setCellStyle(s7);
             }
             track++;
          }
    }
   
}


