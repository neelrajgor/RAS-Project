

package excel;

import retrive.readpdf;
import analysis.A;
import frontend.Frame;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import retrive.StoreData;

public class excel
{
    public excel() throws FileNotFoundException, IOException
    {
        String excel_name=null;
        String path=Frame.url;
        sheet1 S1=new sheet1();
        sheet2 S2=new sheet2();
        sheet3 S3=new sheet3();
        A z=new A();
        readpdf wf=new readpdf();
        
        ArrayList<StoreData> pdf = wf.pdf(path);
        System.out.println("College Name: "+readpdf.college_name);
        System.out.println("Course: "+readpdf.course);
        System.out.println("Year: "+readpdf.year);
        final String yr=readpdf.year;
        System.out.println("SEM: "+readpdf.sem);
        final boolean sem=readpdf.sem;
        if(readpdf.sem)
           excel_name=readpdf.course+"_"+readpdf.year+"_"+"SEM-2";
        else
           excel_name=readpdf.course+"_"+readpdf.year+"_"+"SEM-1";
         String tot_stu=Frame.stu_tot;
         System.out.println("STU "+tot_stu);
         String subject=Frame.sub_tot;
         String[] splitsub = subject.split(",");
                ArrayList<StoreData> passStudent = z.passStudent(pdf,Short.parseShort(tot_stu));
            System.out.println("\t\t\t\t\t\t\tTOPPERS");
            System.out.println("\t\tImplementation #1.0");
            System.out.println("##################################################################################################");
            for(int i=0;i<passStudent.size();i++)
            {
            if(i==5)
            break;
            System.out.println("NAME: "+passStudent.get(i).getName());
            System.out.println("SEAT.NO: "+passStudent.get(i).getSeatNumber());
            System.out.println("SGPA: "+passStudent.get(i).getSgpa());
            }
            System.out.println("\t\t\t\t\t\t\tSUBJECT TOPPERS");
            System.out.println("\t\tImplementation #1.1");
           System.out.println("##################################################################################################");
//            for(String temp:splitsub)
//            {
//             subjectTopper= z.subjectTopper(pdf,temp,Short.parseShort(tot_stu));
//            System.out.println(subjectTopper[0]+"\t"+subjectTopper[1]);
//            }
            System.out.println("##################################################################################################");   
          System.out.println("\t\t\t\t\t\t\tSUBJECT PERCENT");
            System.out.println("\t\tImplementation #1.2");
           System.out.println("##################################################################################################");
            for(String temp:splitsub)
            {
            ArrayList<Integer> subjectPercent = z.subjectPercent(pdf,temp,Short.parseShort(tot_stu));
            System.out.println("Total appeared: "+subjectPercent.get(0));
            System.out.println("Pass count: "+subjectPercent.get(1));
            System.out.println("Fail count: "+subjectPercent.get(2));
            System.out.println("Percentage Result: "+subjectPercent.get(3));
            }
            System.out.println("##################################################################################################");
             System.out.println("\t\t\t\t\t\t\tSTUDENT PERCENT");
            System.out.println("\t\tImplementation #1.3");
            System.out.println("##################################################################################################");
            z.studentPercent(pdf,Short.parseShort(tot_stu));
             System.out.println("##################################################################################################");
            System.out.println("\t\t\t\t\t\t\tFAIL COUNT");
            System.out.println("\t\tImplementation #1.4");
            System.out.println("##################################################################################################");
            ArrayList<Integer> failStudentCount = z.failStudentCount(pdf,Short.parseShort(tot_stu));
            System.out.println("1's subject failed: "+failStudentCount.get(0));
            System.out.println("2's subject failed: "+failStudentCount.get(1));
            System.out.println("3's subject failed: "+failStudentCount.get(2));
            System.out.println("4's+ subject failed: "+failStudentCount.get(3));
            System.out.println("##################################################################################################");
            z.subjectTopper(pdf,"210241",(short)50);
            z.subjectTopper(pdf,"210242",(short)50);
            z.subjectTopper(pdf,"210243",(short)50);
            z.subjectTopper(pdf,"210244",(short)50);
            z.subjectTopper(pdf,"210245",(short)50);
            z.subjectTopper(pdf,"207003",(short)50);
            z.subjectTopper(pdf,"210251",(short)50);
            z.subjectTopper(pdf,"210252",(short)50);
            z.subjectTopper(pdf,"210253",(short)50);
            z.subjectTopper(pdf,"210254",(short)50);
            
        Workbook wb=new HSSFWorkbook();
        String url="D:\\"+excel_name+".xls";
        FileOutputStream out=new FileOutputStream(url);
        
        Sheet s1=wb.createSheet("Main data");
        Sheet s2=wb.createSheet("Toppers");
        Sheet s3=wb.createSheet("Subject-Wise");
        S1.execute(wb,s1,pdf,sem,Short.parseShort(tot_stu));
        S2.execute(wb, s2, passStudent);
        S2.execute2(wb, s2,splitsub,pdf,Short.parseShort(tot_stu));
        S3.execute1(wb, s3,pdf,Short.parseShort(tot_stu));
        S3.execute2(wb,s3,splitsub,pdf,Short.parseShort(tot_stu));
        wb.write(out);
    //}
}
}