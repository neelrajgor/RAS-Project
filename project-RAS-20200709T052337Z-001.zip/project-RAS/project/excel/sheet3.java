package excel;

import analysis.A;
import java.text.DecimalFormat;
import java.util.ArrayList;
import org.apache.poi.ss.usermodel.BorderExtent;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.PropertyTemplate;
import retrive.StoreData;

class sheet3
{
    void execute1(Workbook wb,Sheet s3,ArrayList<StoreData> arr,short total)
    {
        A z=new A();
        Font font1=wb.createFont();
        Row row3=s3.createRow(4);
        Cell cell1=row3.createCell(1);
        CellStyle style1=wb.createCellStyle();
        style1.setAlignment(HorizontalAlignment.CENTER);
        style1.setVerticalAlignment(VerticalAlignment.CENTER);
        font1.setBold(true);
        style1.setFont(font1);
        cell1.setCellValue("FAIL status");
        row3.setHeight((short)800);
        s3.setColumnWidth(1,7000);
        cell1.setCellStyle(style1);
        
        cell1=row3.createCell(2);
        cell1.setCellValue("No of students");
        s3.setColumnWidth(2,6000);
        cell1.setCellStyle(style1);
        
        cell1=row3.createCell(3);
        cell1.setCellValue("Percent");
        s3.setColumnWidth(2,5000);
        cell1.setCellStyle(style1);
        int k=0;
         for(int i=5;i<=8;i++)
        {
            row3=s3.createRow(i);
            row3.setHeight((short)800);
            cell1=row3.createCell(2);
            ArrayList<Integer> fail = z.failStudentCount(arr, total);
            cell1.setCellValue(fail.get(k));
            if(i==5)
            {
               Cell cell2=row3.createCell(1);
               cell2.setCellValue("1 subject fail");
               cell2.setCellStyle(style1);
            }
            if(i==6)
            {
                Cell cell2=row3.createCell(1);
               cell2.setCellValue("2 subject fail");
               cell2.setCellStyle(style1);
            }
            if(i==7)
            {
                 Cell cell2=row3.createCell(1);
               cell2.setCellValue("3 subject fail");
               cell2.setCellStyle(style1);
            }
            if(i==8)
            {
                 Cell cell2=row3.createCell(1);
               cell2.setCellValue("4+ subject fail");
               cell2.setCellStyle(style1);
            }
            cell1.setCellStyle(style1);
            
            float per=((float)fail.get(k)/total)*100;
            DecimalFormat df = new DecimalFormat("#.##");
             cell1=row3.createCell(3);
             cell1.setCellValue(df.format(per)+" %");
             cell1.setCellStyle(style1);
            k++;
        }
         row3=s3.createRow(9);
         row3.setHeight((short)800);
         cell1=row3.createCell(2);
        ArrayList<StoreData> passStudent = z.passStudent(arr, total);
        cell1.setCellValue(passStudent.size());
        cell1.setCellStyle(style1);
        cell1=row3.createCell(1);
        cell1.setCellValue("ALL CLEAR");
        cell1.setCellStyle(style1);
        float per=((float)passStudent.size()/total)*100;
            DecimalFormat df = new DecimalFormat("#.##");
             cell1=row3.createCell(3);
             cell1.setCellValue(df.format(per)+" %");
             cell1.setCellStyle(style1);
         
        PropertyTemplate pt=new PropertyTemplate();
        pt.drawBorders(new CellRangeAddress(4,9,1,3), BorderStyle.MEDIUM, BorderExtent.ALL);
        pt.applyBorders(s3);
    }
    
    void execute2(Workbook wb,Sheet s3,String[] splitsub,ArrayList<StoreData> arr,short total)
    {
       A z=new A();
       Font font1=wb.createFont();
       CellStyle style1=wb.createCellStyle();
        style1.setAlignment(HorizontalAlignment.CENTER);
        style1.setVerticalAlignment(VerticalAlignment.CENTER);
        font1.setBold(true);
        style1.setFont(font1);
        
       Row row=s3.createRow(12);
       Cell c1=row.createCell(1);
       row.setHeight((short)800);
       c1.setCellValue("Sr.No.");
       c1.setCellStyle(style1);
       
       c1=row.createCell(2);
       c1.setCellValue("Subject Name");
       c1.setCellStyle(style1);
       
       c1=row.createCell(3);
       c1.setCellValue("Name of Faculty");
       s3.setColumnWidth(3,6500);
       c1.setCellStyle(style1);
       
       c1=row.createCell(4);
       c1.setCellValue("No of\n student appeared");
        s3.setColumnWidth(4,4000);
       style1.setWrapText(true);
       c1.setCellStyle(style1);
       
       c1=row.createCell(5);
       c1.setCellValue("No of\n student passed");
        s3.setColumnWidth(5,4000);
       style1.setWrapText(true);
       c1.setCellStyle(style1);
       
       c1=row.createCell(6);
       c1.setCellValue("passing \n percentage");
        s3.setColumnWidth(6,3500);
       style1.setWrapText(true);
       c1.setCellStyle(style1);
       
       int count=0;
       int j=1;
       int border=0;
       String replace;
       for(int i=13;i<splitsub.length+13;i++)
      {
          row=s3.createRow(i);
          row.setHeight((short)800);
          c1=row.createCell(2);
          c1.setCellValue(splitsub[count]);
          c1.setCellStyle(style1);
          
           ArrayList<Integer> subjectPercent = z.subjectPercent(arr,splitsub[count],total);
           c1=row.createCell(4);
           c1.setCellValue(subjectPercent.get(0));
           c1.setCellStyle(style1);
           
           c1=row.createCell(5);
           c1.setCellValue(subjectPercent.get(1));
           c1.setCellStyle(style1);
           
           c1=row.createCell(6);
           c1.setCellValue(subjectPercent.get(3)+" %");
           c1.setCellStyle(style1);
          
          c1=row.createCell(1);
          String tempstr=j+".)";
          c1.setCellValue(tempstr);
          c1.setCellStyle(style1);
          count++;
          j++;
          border=i;
      }
        PropertyTemplate pt=new PropertyTemplate();
        pt.drawBorders(new CellRangeAddress(12,border,1,6), BorderStyle.MEDIUM, BorderExtent.ALL);
        pt.applyBorders(s3);
    }
}
