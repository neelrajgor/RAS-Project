package excel;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;

enum Styles
{
    MAINSTYLE,INSEMSTYLE,ENDSEMSTYLE,TOTALSTYLE,TWSTYLE,PRSTYLE,ORSTYLE;

    CellStyle sheet1mainStyle(Workbook wb)  
   {
            Font font1=wb.createFont();
            CellStyle style1=wb.createCellStyle();
            style1.setAlignment(HorizontalAlignment.CENTER);
            style1.setVerticalAlignment(VerticalAlignment.CENTER);
            style1.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
            style1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            style1.setFont(font1);
            style1.setWrapText(true);
            font1.setBold(true);
        return style1;
   }
    
    CellStyle sheet1insemStyle(Workbook wb)  
   {
            Font font1=wb.createFont();
            CellStyle style2=wb.createCellStyle();
            style2.setAlignment(HorizontalAlignment.CENTER);
            style2.setVerticalAlignment(VerticalAlignment.CENTER);
           style2.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.getIndex());
               style2.setFillPattern(FillPatternType.SOLID_FOREGROUND);
               style2.setFont(font1);
            style2.setWrapText(true);
            font1.setBold(true);
        return style2;
   }
    
    CellStyle sheet1endsemStyle(Workbook wb)  
   {
            Font font1=wb.createFont();
            CellStyle style3=wb.createCellStyle();
            style3.setAlignment(HorizontalAlignment.CENTER);
            style3.setVerticalAlignment(VerticalAlignment.CENTER);
             style3.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
              style3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
              style3.setFont(font1);
            style3.setWrapText(true);
            font1.setBold(true);
        return style3;
   }
    
    CellStyle sheet1totalStyle(Workbook wb)  
   {
            Font font1=wb.createFont();
            CellStyle style4=wb.createCellStyle();
            style4.setAlignment(HorizontalAlignment.CENTER);
            style4.setVerticalAlignment(VerticalAlignment.CENTER);
             style4.setFillForegroundColor(IndexedColors.GOLD.getIndex());
               style4.setFillPattern(FillPatternType.SOLID_FOREGROUND);
               style4.setFont(font1);
            style4.setWrapText(true);
            font1.setBold(true);
        return style4;
   }
    
    CellStyle sheet1twStyle(Workbook wb)  
   {
            Font font1=wb.createFont();
            CellStyle style5=wb.createCellStyle();
            style5.setAlignment(HorizontalAlignment.CENTER);
            style5.setVerticalAlignment(VerticalAlignment.CENTER);
            style5.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
               style5.setFillPattern(FillPatternType.SOLID_FOREGROUND);
               style5.setFont(font1);
            style5.setWrapText(true);
            font1.setBold(true);
        return style5;
   }
    
    CellStyle sheet1prStyle(Workbook wb)  
   {
            Font font1=wb.createFont();
            CellStyle style6=wb.createCellStyle();
            style6.setAlignment(HorizontalAlignment.CENTER);
            style6.setVerticalAlignment(VerticalAlignment.CENTER);
            style6.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
               style6.setFillPattern(FillPatternType.SOLID_FOREGROUND);
               style6.setFont(font1);
            style6.setWrapText(true);
            font1.setBold(true);
        return style6;
   }
    
    CellStyle sheet1orStyle(Workbook wb)  
   {
            Font font1=wb.createFont();
            CellStyle style7=wb.createCellStyle();
            style7.setAlignment(HorizontalAlignment.CENTER);
            style7.setVerticalAlignment(VerticalAlignment.CENTER);
           style7.setFillForegroundColor(IndexedColors.PALE_BLUE.getIndex());
               style7.setFillPattern(FillPatternType.SOLID_FOREGROUND);
               style7.setFont(font1);
            style7.setWrapText(true);
            font1.setBold(true);
        return style7;
   }
       
}
