package excel;

import analysis.A;
import java.util.ArrayList;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.usermodel.BorderExtent;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.PropertyTemplate;
import retrive.StoreData;

class sheet2
{
        A z=new A();
  void execute(Workbook wb,Sheet s2,ArrayList<StoreData> passStudent)
  {
       Row row1=s2.createRow(4);
        
        Cell cell2=row1.createCell(1);
        HSSFCellStyle style2 = (HSSFCellStyle) wb.createCellStyle();
        style2.setAlignment(HorizontalAlignment.CENTER);
        style2.setVerticalAlignment(VerticalAlignment.CENTER);
        s2.setColumnWidth(1,2000);
        row1.setHeight((short)800);
        cell2.setCellValue("Sr.No.");
        style2.setWrapText(true);
        cell2.setCellStyle(style2);
        
        cell2=row1.createCell(2);
        s2.setColumnWidth(2,7000);
        cell2.setCellValue("NAME");
        cell2.setCellStyle(style2);
        
        cell2=row1.createCell(3);
        s2.setColumnWidth(3,5000);
        cell2.setCellValue("SGPA");
        cell2.setCellStyle(style2);
        
        cell2=row1.createCell(4);
        s2.setColumnWidth(4,7000);
        cell2.setCellValue("RANK");
        cell2.setCellStyle(style2);
        CellStyle style=wb.createCellStyle();
            Font font = wb.createFont();
            Font font1 = wb.createFont();
            font.setFontHeightInPoints((short)20);    
            font.setBold(true);
            style.setFont(font);
            style.setAlignment(HorizontalAlignment.CENTER);
            style.setVerticalAlignment(VerticalAlignment.CENTER);
            CellStyle cellStyle=wb.createCellStyle();  
            font1.setFontHeightInPoints((short)11);  
            font1.setFontName("Courier New");  
            font1.setBold(true);
            cellStyle.setFont(font1);
            cellStyle.setAlignment(HorizontalAlignment.CENTER);
            cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        int j=1;
        int k=0;
        for(int i=5;i<=9;i++)
        {
        row1=s2.createRow(i);
        row1.setHeight((short)800);
        cell2=row1.createCell(1);
        String tempstr=j+".)";
        cell2.setCellValue(tempstr);
        cell2.setCellStyle(style2);
        cell2=row1.createCell(4);
        cell2.setCellValue(j);      
        cell2.setCellStyle(style);
        j++;
        cell2=row1.createCell(2);
        cell2.setCellValue(passStudent.get(k).getName());
        cell2.setCellStyle(cellStyle);
        cell2=row1.createCell(3);
        cell2.setCellStyle(cellStyle);
        cell2.setCellValue(passStudent.get(k).getSgpa());
        k++;
        }
        PropertyTemplate pt=new PropertyTemplate();
        pt.drawBorders(new CellRangeAddress(4,9,1,4), BorderStyle.MEDIUM, BorderExtent.ALL);
        pt.applyBorders(s2);
  }
  
  void execute2(Workbook wb,Sheet s2,String[] splitsub,ArrayList<StoreData> subjectTopper,short restrict)
  {
      Font font1=wb.createFont();
      Row row2=s2.createRow(12);
      row2.setHeight((short)800);
      Cell cell3=row2.createCell(1);
      CellStyle style1=wb.createCellStyle();
      style1.setAlignment(HorizontalAlignment.CENTER);
      style1.setVerticalAlignment(VerticalAlignment.CENTER);
      font1.setBold(true);
      style1.setFont(font1);
      
      cell3.setCellValue("Sr.No.");
      cell3.setCellStyle(style1);
      
      cell3=row2.createCell(2);
      cell3.setCellValue("SUBJECT NAME");
      cell3.setCellStyle(style1);
      
      cell3=row2.createCell(3);
      cell3.setCellValue("MARKS OBTAINED");
      cell3.setCellStyle(style1);
      
      cell3=row2.createCell(4);
      cell3.setCellValue("NAME");
      cell3.setCellStyle(style1);
      int count=0;
      int j=1;
      int border = 0;
      for(int i=13;i<splitsub.length+13;i++)
      {
          row2=s2.createRow(i);
          row2.setHeight((short)800);
          cell3=row2.createCell(2);
          cell3.setCellValue(splitsub[count]);
          cell3.setCellStyle(style1);
          
          cell3=row2.createCell(3);
          String[] subjectTopper1 = z.subjectTopper(subjectTopper,splitsub[count],restrict);
          cell3.setCellValue(subjectTopper1[1]);
          cell3.setCellStyle(style1);
          
          cell3=row2.createCell(4);
          cell3.setCellValue(subjectTopper1[0]);
          cell3.setCellStyle(style1);
          
          cell3=row2.createCell(1);
          String tempstr=j+".)";
          cell3.setCellValue(tempstr);
          cell3.setCellStyle(style1);
          count++;
          j++;
          border=i;
      }
       PropertyTemplate pt=new PropertyTemplate();
        pt.drawBorders(new CellRangeAddress(12,border,1,4), BorderStyle.MEDIUM, BorderExtent.ALL);
        pt.applyBorders(s2);
  }

   
}