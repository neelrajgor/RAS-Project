package analysis;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import retrive.StoreData;
import retrive.StoreDataMarks;

public class A
{
    short count=0;
    ArrayList<StoreData> temparr1=new ArrayList<>();
    ArrayList<StoreData> temparr2=new ArrayList<>();
    public ArrayList<StoreData> passStudent(ArrayList<StoreData> s,short restrict)
    {
       for(StoreData ss:s)
       {
           count++;
           if(count==restrict)
               break;
           if(ss.getSgpa()==0.0)
               continue;
           else if(ss.getSgpa()>0.0)
               temparr1.add(ss);
       }
       System.out.println("TOTAL ALL CLEAR-> "+temparr1.size());
       for(StoreData d:temparr1)
       {
           System.out.println(d.getName()+"  "+d.getSgpa());
       }
       Comparator<StoreData> cmp=Comparator.comparing(StoreData::getSgpa).reversed();
       Collections.sort(temparr1,cmp);
       return temparr1;
    }
    
     public String[] subjectTopper(ArrayList<StoreData> s,String sub,short restrict)
    {
        int max=-100;
        String name=null;
        int count1=0;
        String arr[]=new String[2];
        for(StoreData ss:s)
        {
            count1++;
              if(count1==restrict)
                  break;
            for(StoreDataMarks sss:ss.getMarksArray())
            {
                if(sss.getSubject().contains(sub) && sss.getInsemEndsemMarks()>max)
                {
                    name=ss.getName();
                    max=sss.getInsemEndsemMarks();
                }
                
            }
        }
         arr[0]=name;
         arr[1]=Integer.toString(max);
        return arr;
    }
     
      public ArrayList<Integer> subjectPercent(ArrayList<StoreData> s,String sub,short restrict)
     {
         ArrayList<Integer> arr1=new ArrayList<>();
         byte count1=0,count2=0;
         ArrayList<String> arr=new ArrayList<>();
         int add=0;
          for(StoreData s1:s)
          {                           //update's done
              count2++;
              if(count2==restrict)
                  break;
              for(StoreDataMarks s2:s1.getMarksArray())
              {
                  if(s2.getSubject().contains(sub) && s2.getEndsemTotal()!=0)
                  {
                     arr.add(s2.getGrade()); 
                  }
              }
          }
          for(int i=0;i<arr.size();i++)
          {
              if(arr.get(i).contains("F"))
                  count1++;
          }
          float a=((float)(restrict-count1)/restrict)*100;
          arr1.add((int)restrict);
          int b=(restrict-count1);
          arr1.add(b);
          arr1.add((int)count1);
          arr1.add((int)a);
         return arr1;
     } 
      
     public ArrayList<Float> studentPercent(ArrayList<StoreData> s,short restrict)
      {
          ArrayList<Float> arr1=new ArrayList<>();
          int total=0;
             total=s.get(0).total(s.get(0).getMarksArray(),s.get(3).getSubjectCount());
          System.out.println("GRAND TOTAL--> "+total);
          int count1=0; 
            for(int i=0;i<s.size();i++)
            {
                 count1++;
               if(count1==restrict)                       //update's done
                   break;
              int obtained_marks=s.get(i).total_marks(s.get(i).getMarksArray(),s.get(i).getSubjectCount());
              float percent_result=((float)obtained_marks/total)*100;
              DecimalFormat df = new DecimalFormat("#.##");
              System.out.println("\t\t\t\t"+s.get(i).getName());
              System.out.println("PERCENTAGE-> "+df.format(percent_result)+"%");
              arr1.add(Float.parseFloat(df.format(percent_result)));
              System.out.println("MARKS OBTAINED-> "+obtained_marks);
              System.out.println("GRAND TOTAL-> "+total);
            }
          return arr1;
      }

      public ArrayList<Float> studentPercent(ArrayList<StoreData> s,boolean bool)
      {
          ArrayList<Float> arr1=new ArrayList<>();
          int total=0;
             total=s.get(0).total(s.get(0).getMarksArray(),s.get(3).getSubjectCount());  //update's done
          if(bool)
          {
             for(int i=0;i<s.size();i++)
            {
              int obtained_marks=s.get(i).total_marks(s.get(i).getMarksArray(),s.get(i).getSubjectCount());
              float percent_result=((float)obtained_marks/total)*100;
              DecimalFormat df = new DecimalFormat("#.##");
              System.out.println("\t\t\t\t"+s.get(i).getName());
              System.out.println("PERCENTAGE-> "+df.format(percent_result)+"%");
              arr1.add(Float.parseFloat(df.format(percent_result)));
              System.out.println("MARKS OBTAINED-> "+obtained_marks);
              System.out.println("GRAND TOTAL-> "+total);
            } 
          }
          else                                                             //update's done
          {
            for(int i=0;i<s.size();i++)
            {
              int obtained_marks=s.get(i).total_marks(s.get(i).getMarksArray(),s.get(i).getSubjectCount());
              float percent_result=((float)obtained_marks/total)*100;
              DecimalFormat df = new DecimalFormat("#.##");
              System.out.println("\t\t\t\t"+s.get(i).getName());
              System.out.println("PERCENTAGE-> "+df.format(percent_result)+"%");
              System.out.println("MARKS OBTAINED-> "+obtained_marks);
              arr1.add((float)obtained_marks);
              System.out.println("GRAND TOTAL-> "+total);
            }
            }
          return arr1;
      }      
      
      public ArrayList<Integer> failStudentCount(ArrayList<StoreData> s,short restrict)
      {
          int count1=0,count2=0,count3=0,count4=0;
          int count0=0;
          ArrayList<Integer> arr=new ArrayList<>();
          ArrayList<Integer> arr2=new ArrayList<>();
          int add=0;
            for(int i=0;i<s.size();i++)
            {
                count0++;
                if(count0==restrict)
                    break;
              int count=s.get(i).countFail(s.get(i).getMarksArray(),s.get(i).getSubjectCount());     //update's done
              arr.add(count);
            }
          for(int i=0;i<arr.size();i++)
          {
              if(arr.get(i)==1)
                  count1++;
              if(arr.get(i)==2)
                  count2++;
              if(arr.get(i)==3)
                  count3++;
              if(arr.get(i)>=4)
                  count4++;
          }
          arr.clear();
          arr.add(count1);
          arr.add(count2);
          arr.add(count3);
          arr.add(count4);
        return arr;
      }
}