package frontend;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;

public class Scroll {
//Document doc;
    public Scroll() {
        JFrame jFrame=new JFrame();
        JButton jButton=new JButton("History");
        Font font1=new Font("",Font.BOLD,30);
        jButton.setFont(font1);
        jButton.setBounds(450,590,250,40);
        jFrame.setSize(1000,700);
        jFrame.setLayout(null);
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLayout(new BorderLayout());
        jFrame.setContentPane(new JLabel(new ImageIcon("C:\\Tr.jpg")));

        JTextArea jTextArea=new JTextArea();
       // doc.getString(doc);
        JScrollPane jScrollPane = new JScrollPane(jTextArea);
        DefaultCaret defaultCaret= (DefaultCaret) jTextArea.getCaret();
        defaultCaret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

jScrollPane.setLocation(300,200);
jScrollPane.setSize(500,200);

jFrame.add(jButton);
jFrame.add(jScrollPane);
jFrame.setVisible(true);
jFrame.setLocation(170,20);


    }

}