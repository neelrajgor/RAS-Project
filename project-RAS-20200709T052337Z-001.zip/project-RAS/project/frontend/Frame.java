package frontend;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Frame extends JFrame  {
 public static String url;
       public static String stu_tot;
       public static String sub_tot;
    public Frame() throws HeadlessException {
        JFrame frame = new JFrame("file chooser");

        JTextField textField= new JTextField("");
        JButton button1 = new JButton("Browse");
        JButton button2 = new JButton("Submit");
        Font font=new Font("",Font.ITALIC,25);
        Font font1=new Font("",Font.BOLD,30);
      textField.setFont(font);

//button1.setFont(font);
        button2.setFont(font1);
        button1.setBounds(909,250,20,30);
        button2.setBounds(450,590,250,40);
        textField.setBounds(210,250, 700,30);
     frame.setLayout(new BorderLayout());
       frame.setContentPane(new JLabel(new ImageIcon("C:\\Tr.jpg")));
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String com = e.getActionCommand();
                if (com.equals("Browse")) {
                    JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
                    j.setAcceptAllFileFilterUsed(false);
                    j.setDialogTitle("Select a .pdf file");
                    FileNameExtensionFilter restrict = new FileNameExtensionFilter("Only .pdf files", "pdf");
                    j.addChoosableFileFilter(restrict);
                    int r = j.showSaveDialog(null);
                    if (r == JFileChooser.APPROVE_OPTION) {
                        textField.setText(j.getSelectedFile().getAbsolutePath());
                        url=textField.getText();
                    }
                    else
                        JOptionPane.showMessageDialog(null,"The user cancelled the operation");
                }
            }
        });
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String file=textField.getText();
                if (file.endsWith(".pdf"))
                {

                   stu_tot= JOptionPane.showInputDialog("Enter the Total number Students",null);
                    sub_tot=JOptionPane.showInputDialog("Enter the subject code separated by comma",null);
                    new Lpage();
                    frame.dispose();

                }
                else
                    JOptionPane.showMessageDialog(null,"Wrong Input");
            }
        });

        frame.setResizable(false);
        frame.setLocation(170,20);
        frame.add(textField);
        frame.add(button1);
        frame.add(button2);
        frame.setSize(1000,700);
        frame.setBackground(Color.BLUE);
        frame.setLayout(null);
        frame.setVisible(true);

    }
}