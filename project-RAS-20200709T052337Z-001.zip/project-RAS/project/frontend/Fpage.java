package frontend;

import javafx.scene.shape.Circle;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Fpage extends JFrame {

    public Fpage() {
        JFrame frame= new JFrame("Result Analysis System");
        JButton jbutton=new JButton();
        JLabel jlabel3=new JLabel();

        frame.setLayout(new BorderLayout());
        frame.setContentPane(new JLabel(new ImageIcon("C:\\Tr.jpg")));

//frame.add(new JLabel(new ImageIcon("C:\\Users\\Amit\\Pictures\\Saved Pictures\\p3.gif")));

        jbutton.setForeground(Color.BLACK);
        jlabel3.setForeground(Color.darkGray);

        Font font2=new Font("",Font.BOLD,40);
        Font font=new Font("", Font.BOLD,50);
        jlabel3.setBounds(225,10,2000,150);
        jlabel3.setText("Result Analysis System");
        jlabel3.setFont(font);
        jbutton.setBounds(400,590,250,45);
        jbutton.setText("Next ->");
        jbutton.setFont(font2);

        jbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Frame();
                frame.dispose();
            }
        });
        frame.setResizable(false);
      //  frame.getContentPane().setBackground(Color.GREEN);
        frame.setLocation(170,20);
        frame.setForeground(Color.blue);
        frame.add(jlabel3);
        frame.add(jbutton);
        frame.setSize(1000,700);
        frame.setBackground(getBackground());
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}