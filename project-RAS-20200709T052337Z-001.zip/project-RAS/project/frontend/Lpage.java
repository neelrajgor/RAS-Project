package frontend;

import excel.excel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Lpage {

    public Lpage() {

        JFrame frame = new JFrame("frame");
        JButton jButton=new JButton("Submit");
         JButton jButton1=new JButton("Next");
        jButton.setBounds(250,600,200,40);
        jButton1.setBounds(700,600,200,40);
      frame.setLayout(new BorderLayout());
        frame.setContentPane(new JLabel(new ImageIcon("C:\\Tr.jpg")));
        String s[] = { ".xls" };
        JComboBox jComboBox= new JComboBox(s);
        Font font=new Font("",Font.ITALIC,25);
        jComboBox.setFont(font);
        ((JLabel)jComboBox.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        jComboBox.setBounds(210,350,700,30);
        Font font1=new Font("",Font.BOLD,30);
        jButton.setFont(font1);
jButton1.setFont(font1);
        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s1 = (String) jComboBox.getSelectedItem();
                if (s1.endsWith(".xls"))
                {
                   
                    try {
                        new excel();
                        frame.dispose();
                    } catch (IOException ex) {
                        Logger.getLogger(Lpage.class.getName()).log(Level.SEVERE, null, ex);
                    }    
                }
            }
        });
        
       jButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            new Scroll();
            frame.dispose();
                }
        });
       frame.add(jButton1);
        frame.setResizable(false);
        frame.setLocation(170,20);
        frame.add(jButton);
      //  frame.add(jLabel);
        frame.add(jComboBox);
        frame.setSize(1000, 700);
       // frame.setLayout(new FlowLayout());
        frame.setLayout(null);
        frame.setVisible(true);
}
}